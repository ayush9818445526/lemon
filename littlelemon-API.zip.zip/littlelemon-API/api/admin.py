from django.contrib import admin
from .models import MenuItem, Category, OrderItem, Cart, PurchaseItem, Purchase, Order

# Register your models here.
admin.site.register(MenuItem)
admin.site.register(Category)
admin.site.register(OrderItem)
admin.site.register(Cart)
admin.site.register(PurchaseItem)
admin.site.register(Purchase)
admin.site.register(Order)
